#include "dll.h"

int dl_insert_after(Dlist **head, Dlist **tail, int gdata, int ndata)
{
    if (*head == NULL)
        return LIST_EMPTY;

    Dlist *current = *head;
    while (current != NULL)
    {
        if (current->data == gdata)
        {
            Dlist *new_node = malloc(sizeof(Dlist));
            if (new_node == NULL)
                return FAILURE;

            new_node->data = ndata;
            new_node->prev = current;
            new_node->next = current->next;

            if (current->next == NULL)
            {
                *tail = new_node;
            }
            else
            {
                current->next->prev = new_node;
            }

            current->next = new_node;
            return SUCCESS;
        }

        current = current->next;
    }

    return DATA_NOT_FOUND;
}
