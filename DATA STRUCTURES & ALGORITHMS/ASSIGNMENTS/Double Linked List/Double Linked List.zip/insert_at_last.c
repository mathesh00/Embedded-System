#include "dll.h"

int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
    Dlist *new_node = malloc(sizeof(Dlist));
    if (new_node == NULL)
        return FAILURE;

    new_node->data = data;
    new_node->prev = *tail;
    new_node->next = NULL;

    if (*head == NULL)
    {
        *head = *tail = new_node;
    }
    else
    {
        (*tail)->next = new_node;
        *tail = new_node;
    }

    return SUCCESS;
}
