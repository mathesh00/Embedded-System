#include "dll.h"

int dl_delete_list(Dlist **head, Dlist **tail)
{
    if (*head == NULL)
        return FAILURE;

    Dlist *current = *head;
    Dlist *next;

    while (current != NULL)
    {
        next = current->next;
        free(current);
        current = next;
    }

    *head = *tail = NULL;
    return SUCCESS;
}
