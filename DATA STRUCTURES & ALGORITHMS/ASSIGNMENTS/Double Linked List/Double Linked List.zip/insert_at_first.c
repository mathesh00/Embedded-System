#include "dll.h"

int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *new_node = malloc(sizeof(Dlist));
    if (new_node == NULL)
        return FAILURE;

    new_node->data = data;
    new_node->prev = NULL;
    new_node->next = *head;

    if (*head == NULL)
    {
        *head = *tail = new_node;
    }
    else
    {
        (*head)->prev = new_node;
        *head = new_node;
    }

    return SUCCESS;
}
