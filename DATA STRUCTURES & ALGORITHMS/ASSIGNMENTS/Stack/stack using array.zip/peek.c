#include "stack.h"

int Peek(Stack_t *s)
{
    if (s->top == -1)
    {
        return STACK_EMPTY;
    }

    return s->stack[s->top];
}
