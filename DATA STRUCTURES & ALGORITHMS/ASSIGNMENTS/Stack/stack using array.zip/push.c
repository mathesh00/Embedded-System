#include "stack.h"

int Push(Stack_t *s, int element)
{
    if (s->top == s->capacity - 1)
    {
        return STACK_FULL;
    }

    s->stack[++s->top] = element;
    return SUCCESS;
}
