#include "stack.h"

int Pop(Stack_t *s)
{
    if (s->top == -1)
    {
        return STACK_EMPTY;
    }

    s->top--;
    return SUCCESS;
}
