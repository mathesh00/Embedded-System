#include "stack.h"

int Push(Stack_t **top, data_t data)
{
    Stack_t *newNode = (Stack_t *)malloc(sizeof(Stack_t));
    if (newNode == NULL)
    {
        // Memory allocation failed
        return FAILURE;
    }

    newNode->data = data;
    newNode->link = *top;
    *top = newNode;

    return SUCCESS;
}
