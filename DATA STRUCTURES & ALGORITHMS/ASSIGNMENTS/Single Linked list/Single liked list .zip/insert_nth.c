#include "sll.h"

int sl_insert_nth(Slist **head, data_t e_data, data_t data)
{
    if (e_data < 1)
        return POSITION_NOT_FOUND;

    Slist *new_node = malloc(sizeof(Slist));
    if (new_node == NULL)
        return FAILURE;

    new_node->data = data;

    if (e_data == 1 || *head == NULL)
    {
        new_node->link = *head;
        *head = new_node;
        return SUCCESS;
    }

    Slist *current = *head;
    for (int i = 1; i < e_data - 1 && current != NULL; ++i)
    {
        current = current->link;
    }

    if (current == NULL)
    {
        free(new_node);
        return POSITION_NOT_FOUND;
    }

    new_node->link = current->link;
    current->link = new_node;

    return SUCCESS;
}
