#include "sll.h"

int reverse_iter(Slist **head) {
    if (*head == NULL) {
        printf("INFO : List is empty\n");
        return LIST_EMPTY;
    }

    Slist *prev = NULL, *cur = *head, *next;

    while (cur) {
        next = cur->link;
        cur->link = prev;
        prev = cur;
        cur = next;
    }

    *head = prev;
    return SUCCESS;
}
