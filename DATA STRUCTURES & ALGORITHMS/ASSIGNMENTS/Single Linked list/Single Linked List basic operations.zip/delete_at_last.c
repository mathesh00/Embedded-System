#include "sll.h"

int sl_delete_last(Slist **head)
{
    // Validation
    if (*head == NULL)
    {
        return LIST_EMPTY;
    }

    // Assigning the head value to a temporary pointer variable
    Slist *temp = *head;

    // Check for the first node
    if (temp->link == NULL)
    {
        free(*head);
        *head = NULL;
        return SUCCESS;
    }

    // Traverse to the last node
    while (temp->link->link)
    {
        temp = temp->link;
    }

    // Free the last node
    free(temp->link);

    // Set the link of the second last node to NULL
    temp->link = NULL;

    return SUCCESS;
}

