#include "sll.h"

int find_node(Slist *head, data_t data)
{
    if (head == NULL)
    {
        return LIST_EMPTY; // List is empty
    }

    int position = 1;
    Slist *current = head;

    while (current != NULL)
    {
        if (current->data == data)
        {
            return position; // Data found
        }
        current = current->link;
        position++;
    }

    return DATA_NOT_FOUND; // Data not found
}
