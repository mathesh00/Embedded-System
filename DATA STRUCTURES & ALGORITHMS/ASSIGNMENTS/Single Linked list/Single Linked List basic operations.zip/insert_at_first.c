#include "sll.h"

int insert_at_first(Slist **head, data_t data)
{
    Slist *new_node = (Slist *)malloc(sizeof(Slist));
    if (new_node == NULL)
    {
        return FAILURE; // Memory allocation failed
    }

    new_node->data = data;
    new_node->link = *head;
    *head = new_node;

    return SUCCESS;
}
