#include "sll.h"

int sl_delete_first(Slist **head)
{
    if (*head == NULL)
    {
        return LIST_EMPTY; // List is empty
    }

    Slist *temp = *head;
    *head = (*head)->link;
    free(temp);

    return SUCCESS;
}
