#include "sll.h"

int sl_delete_list(Slist **head)
{
    if (*head == NULL)
    {
        return LIST_EMPTY; // List is empty
    }

    Slist *current = *head;
    Slist *next;

    while (current != NULL)
    {
        next = current->link;
        free(current);
        current = next;
    }

    *head = NULL; // Important: set head to NULL after deleting all nodes

    return SUCCESS;
}
