#include "sll.h"

int find_nth_last(Slist *head, int pos, int *data) 
{
    if (head == NULL)
        return LIST_EMPTY;

    int len = 0;
    Slist *temp = head;

    // Calculate the length of the list
    while (temp != NULL)
    {
        len++;
        temp = temp->link;
    }

    // Check if the position is valid
    if (pos <= 0 || pos > len)
        return POSITION_NOT_FOUND;

    // Reset temp to the head
    temp = head;

    // Traverse to the nth last node
    for (int i = 0; i < len - pos; i++)
        temp = temp->link;

    // Store the data of the nth last node
    *data = temp->data;

    return SUCCESS;
}
