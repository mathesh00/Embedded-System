#include "main.h"
#include <string.h>

int Infix_Postfix_conversion(char *Infix_exp, char *Postfix_exp, Stack_t *stk) {
    int i, j = 0;
    char ch;

    for (i = 0; Infix_exp[i] != '\0'; i++) {
        ch = Infix_exp[i];

        if (isalnum(ch)) {
            Postfix_exp[j++] = ch;
        } else if (ch == '(') {
            push(stk, ch);
        } else if (ch == ')') {
            while (peek(stk) != -1 && peek(stk) != '(') {
                Postfix_exp[j++] = peek(stk);
                pop(stk);
            }
            pop(stk); // Pop the '('
        } else {
            while (peek(stk) != -1 && priority(ch) <= priority(peek(stk))) {
                Postfix_exp[j++] = peek(stk);
                pop(stk);
            }
            push(stk, ch);
        }
    }

    while (peek(stk) != -1) {
        Postfix_exp[j++] = peek(stk);
        pop(stk);
    }

    Postfix_exp[j] = '\0';

    return 0;
}
