#include "main.h"
#include <stdio.h>
#include <stdlib.h>

int Postfix_Eval(char *Postfix_exp, Stack_t *stk) {
    int i, op1, op2, result;

    for (i = 0; Postfix_exp[i] != '\0'; i++) {
        char ch = Postfix_exp[i];

        if (isdigit(ch)) {
            push(stk, ch - '0'); // Convert character to integer
        } else {
            op2 = peek(stk);
            pop(stk);
            op1 = peek(stk);
            pop(stk);

            switch (ch) {
                case '+':
                    result = op1 + op2;
                    break;
                case '-':
                    result = op1 - op2;
                    break;
                case '*':
                    result = op1 * op2;
                    break;
                case '/':
                    result = op1 / op2;
                    break;
            }

            push(stk, result);
        }
    }

    return peek(stk);
}
