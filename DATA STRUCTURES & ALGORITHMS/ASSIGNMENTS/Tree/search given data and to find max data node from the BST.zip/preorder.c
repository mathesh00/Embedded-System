#include "tree.h"

/* Function to print the tree in pre order */
int preorder(Tree_t *root)
{
    if (root)
    {
        // Print the current node's data
        printf("%d ", root->data);
        
        // Move to the left subtree
        preorder(root->left);
        
        // Move to the right subtree
        preorder(root->right);
    }
    return SUCCESS;
}
