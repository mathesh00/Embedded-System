#include "tree.h"

extern int status;
/* Function to delete the node  */
Tree_t * delete_BST(Tree_t * root, int data)
{
    Tree_t *temp;

    if (root == NULL)
    {
        status = 0;
        return root;
    }

    if (data < root->data)
        root->left = delete_BST(root->left, data);
    else if (data > root->data)
        root->right = delete_BST(root->right, data);
    else
    {
        if (root->left == NULL)
        {
            temp = root->right;
            free(root);
            status = 1;
            return temp;
        }
        else if (root->right == NULL)
        {
            temp = root->left;
            free(root);
            status = 1;
            return temp;
        }

        // Node with two children: Get the inorder successor
        temp = root->right;
        while (temp->left != NULL)
            temp = temp->left;

        // Copy the inorder successor's data to this node
        root->data = temp->data;

        // Delete the inorder successor
        root->right = delete_BST(root->right, temp->data);
        status = 1;
    }

    return root;
}
