/*
Name : Mathesh
Date : 15.11.2023
Description : Generate consecutive NRPS of length n using k distinct character
Sample input : Enter the number characters C : 3
			   Enter the Length of the string N : 6
			   Enter 3 distinct characters : a b c
Sample output :Possible NRPS is abcbca
*/


#include <stdio.h>

void generateNRPS(char *characters, int numCharacters, int length);

int main() {
    int numCharacters, length;

    printf("Enter the number characters C : ");
    scanf("%d", &numCharacters);

    printf("Enter the Length of the string N : ");
    scanf("%d", &length);

    char distinctCharacters[numCharacters];
    printf("Enter %d distinct characters : ", numCharacters);

    for (int i = 0; i < numCharacters; i++) {
        scanf(" %c", &distinctCharacters[i]);
    }

    generateNRPS(distinctCharacters, numCharacters, length);

    return 0;
}

void generateNRPS(char *characters, int numCharacters, int length) {
    int i, j;
    char temp;

    // Check for distinct characters
    for (i = 0; i < numCharacters; i++) {
        for (j = 0; j < numCharacters; j++) {
            if (characters[i] == characters[j] && j != i) {
                printf("Error : Enter distinct characters\n");
                return;
            }
        }
    }

    i = 0;
    printf("Possible NRPS is ");

    while (i < length) {
        for (j = 0; j < numCharacters && i < length; j++) {
            printf("%c", characters[j]);
            i++;
        }

        // Rotate the characters
        temp = characters[0];
        for (int k = 1; k < numCharacters; k++) {
            characters[k - 1] = characters[k];
        }
        characters[numCharacters - 1] = temp;
    }

    printf("\n");
}

