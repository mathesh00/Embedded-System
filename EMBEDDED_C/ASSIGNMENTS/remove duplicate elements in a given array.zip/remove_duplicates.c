/*
Name : Mathesh
Date : 19.10.2023
Description : Remove duplicate elements in a given array
Sample input : Enter the size: 5
			   Enter elements into the array: 5 1 3 1 5
Sample output : After removing duplicates: 5 1 3
*/


#include <stdio.h>

void fun(int *arr1, int size, int *arr2, int *new_size);

int main() {
    int size;

    // Read size from the user
    printf("Enter the size: ");
    scanf("%d", &size);

    int arr1[size];

    // Read elements into the array
    printf("Enter elements into the array: ");
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr1[i]);
    }

    int arr2[size];  // To store the array with duplicates removed
    int new_size = 0;  // Size of the new array

    // Call the function to remove duplicates
    fun(arr1, size, arr2, &new_size);

    // Print the result
    printf("After removing duplicates: ");
    for (int i = 0; i < new_size; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");

    return 0;
}

void fun(int *arr1, int size, int *arr2, int *new_size) {
    for (int i = 0; i < size; i++) {
        int isDuplicate = 0;
        for (int j = 0; j < *new_size; j++) {
            if (arr1[i] == arr2[j]) {
                isDuplicate = 1;
                break;
            }
        }
        if (!isDuplicate) {
            arr2[(*new_size)++] = arr1[i];
        }
    }
}

