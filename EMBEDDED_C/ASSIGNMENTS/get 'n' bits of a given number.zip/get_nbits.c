/*
Name : Mathesh
Date : 14.10.2023
Description : Get 'n' bits of a given number
Sample input : Enter the number: 10
			   Enter number of bits: 3
Sample output : Result = 2
*/

#include <stdio.h>

int get_nbits(int num, int n);

int main() {
    int num, n, res = 0;

    printf("Enter the number: ");
    scanf("%d", &num);
    printf("Enter number of bits: ");
    scanf("%d", &n);

    res = get_nbits(num, n);

    printf("Result = %d\n", res);

    return 0;
}

int get_nbits(int num, int n) {
    // Create a bitmask with 'n' bits set to 1
    int bitmask = (1 << n) - 1;

    // Use bitwise AND to extract the 'n' bits
    int result = num & bitmask;

    return result;
}

