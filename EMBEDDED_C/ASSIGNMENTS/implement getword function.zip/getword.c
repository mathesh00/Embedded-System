/*
Name : Mathesh
Date : 24.10.2023
Description : To implement getword function
Sample input : Enter the string : Welcome to Emertxe
Sample output : You entered Welcome and the length is 7
*/


#include <stdio.h>
#include <ctype.h>

int getword(char *input, char *word);

int main() {
    char str[100];
    char word[100]; // Allocate space for the word

    printf("Enter the string : ");
    scanf(" %[^\n]", str);

    int len = getword(str, word);

    if (len > 0) {
        printf("You entered %s and the length is %d\n", word, len);
    } else {
        printf("You entered %s and the length is %lu\n", str, strlen(str));
    }

    return 0;
}

int getword(char *input, char *word) {
    int len = 0;

    // Skip leading spaces or non-alphabet characters
    while (*input && !isalpha(*input)) {
        input++;
    }

    // Count the word length and copy it to the 'word' array
    while (*input && isalpha(*input)) {
        len++;
        *word = *input;
        word++;
        input++;
    }

    *word = '\0'; // Null-terminate the word

    return len;
}
