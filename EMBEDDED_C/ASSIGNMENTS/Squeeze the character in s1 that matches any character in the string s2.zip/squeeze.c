/*
Name : Mathesh
Date : 02.11.2023
Description : Squeeze the character in s1 that matches any character in the string s2
Sample input : Enter s1 : Dennis Ritchie
			   Enter s2 : Linux
Sample output : After squeeze s1 : Des Rtche
*/


#include <stdio.h>

void squeeze(char s1[], char s2[]);

int main() {
    char str1[30], str2[30];

    printf("Enter s1 : ");
    scanf(" %[^\n]", str1);

    printf("Enter s2 : ");
    scanf(" %[^\n]", str2);

    squeeze(str1, str2);

    printf("After squeeze s1 : %s\n", str1);

    return 0;
}

void squeeze(char s1[], char s2[]) {
    int i, j, k;

    for (i = 0; s2[i] != '\0'; i++) {
        for (j = k = 0; s1[j] != '\0'; j++) {
            if (s1[j] != s2[i]) {
                s1[k++] = s1[j];
            }
        }
        s1[k] = '\0';
    }
}

