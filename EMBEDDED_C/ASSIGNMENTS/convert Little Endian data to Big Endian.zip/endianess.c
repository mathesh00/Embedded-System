/*
Name : Mathesh
Date : 05.11.2023
Description : Convert Little Endian data to Big Endian
Sample input : Enter the size: 2
			   Enter any number in Hexadecimal: ABCD
Sample output : After conversion CDAB
*/


#include <stdio.h>

void convertEndianess(void *data, int size) {
    // Pointer to the given data
    char *ptr = (char *)data;

    // Swap the bytes based on the size
    for (int i = 0; i < size / 2; i++) {
        char temp = ptr[i];
        ptr[i] = ptr[size - i - 1];
        ptr[size - i - 1] = temp;
    }
}

int main() {
    int size;

    // Input: Read the size of the datatype (2 or 4)
    printf("Enter the size: ");
    scanf("%d", &size);

    // Input: Read the number in hexadecimal
    unsigned int num;
    printf("Enter any number in Hexadecimal: ");
    scanf("%X", &num);

    // Convert the endianess
    convertEndianess(&num, size);

    // Output: Print the result in hexadecimal
    printf("After conversion %X\n", num);

    return 0;
}

