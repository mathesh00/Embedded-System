/*
Name : Mathesh
Date : 02.11.2023
Description : Implement atoi function
Sample input : Enter a numeric string: 12345
Sample output : String to integer is 12345
*/


#include <stdio.h>

int my_atoi(const char *s);

int main() {
    char str[20];

    printf("Enter a numeric string: ");
    scanf("%s", str);

    printf("String to integer is %d\n", my_atoi(str));

    return 0;
}

int my_atoi(const char *s) {
    int result = 0;
    int sign = 1;

    // Skip leading whitespaces
    while (*s == ' ' || *s == '\t') {
        s++;
    }

    // Check for the sign
    if (*s == '-') {
        sign = -1;
        s++;
    } else if (*s == '+') {
        s++;
    }

    // Convert the digits to integer
    while (*s >= '0' && *s <= '9') {
        result = result * 10 + (*s - '0');
        s++;
    }

    return sign * result;
}

