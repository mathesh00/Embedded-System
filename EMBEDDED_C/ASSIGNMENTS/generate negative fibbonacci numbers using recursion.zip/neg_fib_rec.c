/*
Name : Mathesh
Date : 22.11.2023
Description : Generate negative fibbonacci numbers using recursion
Sample input : Enter a number: -8
Sample output : 0, 1, -1, 2, -3, 5, -8
*/


#include <stdio.h>
 
void negative_fibonacci(int, int, int, int);                     // function and parameters

int main()
{
    int limit;                                                   // variable declaration
    
    printf("Enter a number: ");                                // read limit from user
    scanf("%d", &limit);
    
    negative_fibonacci(limit, 0, 1, 0);                          
}

void negative_fibonacci(int num, int n1, int n2, int next)       // function prototype

{
    if(num > 0)                                                  // user entered +ve value to print the error messaage
    {
        printf("Invalid input\n");
    }
    
    while( next >= num && next <= (-num))	                     // to generate the negative fibonacci series
    {
         printf("%d, ",next);
	     n1=n2;
	     n2=next;
	     next=n1-n2;	 
    }
}
