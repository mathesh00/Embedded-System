/*
Name : Mathesh
Date : 07.10.2023
Description : Generate AP, GP, HP series
Sample input : Enter the First Number 'A': 2
			   Enter the Common Difference / Ratio 'R': 3
			   Enter the number of terms 'N': 5
Sample output : AP = 2, 5, 8, 11, 14
				GP = 2, 6, 18, 54, 162
				HP = 0.500000, 0.200000, 0.125000, 0.090909, 0.071428
*/

#include <stdio.h>
#include <math.h>

int main() {
    int A, N;
    double R; // Use double for the common ratio

    // Input
    printf("Enter the First Number 'A': ");
    scanf("%d", &A);

    printf("Enter the Common Difference / Ratio 'R': ");
    scanf("%lf", &R); // Use %lf for double

    printf("Enter the number of terms 'N': ");
    scanf("%d", &N);

    if (N <= 0) {
        printf("Invalid input\n");
    } else {
        printf("AP = ");
        for (int i = 0; i < N; i++) {
            printf("%d, ", A + i * (int)R); // Cast R to int for AP
        }

        printf("\nGP = ");
        for (int i = 0; i < N; i++) {
            printf("%.0f, ", A * pow(R, i));
        }

        printf("\nHP = ");
        for (int i = 0; i < N; i++) {
            printf("%.6f, ", 1.0 / (A + i * (int)R)); // Cast R to int for HP
        }

        printf("\n");
    }

    return 0;
}

