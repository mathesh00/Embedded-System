/*
Name : Mathesh
Date : 19.10.2023
Description : Find 3rd largest element in an array
Sample input : Enter the size of the Array : 5
			   Enter the elements into the array: 5 1 4 2 8
Sample output : Third largest element of the array is 4
*/


#include <stdio.h>

int third_largest(int *arr, int size) {
    if (size < 3) {
        printf("Array should have at least three elements to find the third largest.\n");
        return -1;
    }

    int first_max = arr[0];
    int second_max = -1; // Initialize to an invalid value
    int third_max = -1;  // Initialize to an invalid value

    for (int i = 1; i < size; i++) {
        if (arr[i] > first_max) {
            third_max = second_max;
            second_max = first_max;
            first_max = arr[i];
        } else if (arr[i] < first_max && (second_max == -1 || arr[i] > second_max)) {
            third_max = second_max;
            second_max = arr[i];
        } else if (arr[i] < second_max && (third_max == -1 || arr[i] > third_max)) {
            third_max = arr[i];
        }
    }

    return third_max;
}

int main() {
    int size;

    printf("Enter the size of the Array : ");
    scanf("%d", &size);

    if (size <= 0) {
        printf("Array size should be positive.\n");
        return 1;
    }

    int arr[size];

    printf("Enter the elements into the array: ");
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }

    int result = third_largest(arr, size);

    if (result != -1) {
        printf("Third largest element of the array is %d\n", result);
    }

    return 0;
}


