/*
Name : Mathesh
Date : 16.10.2023
Description : Implement your own islower() function
Sample input : Enter the character: a
Sample output : Entered character is lower case alphabet
*/


#include <stdio.h>

int my_islower(int c) {
    return (c >= 'a' && c <= 'z');
}

int main() {
    char ch;
    int ret;

    printf("Enter the character: ");
    scanf(" %c", &ch);

    if (my_islower(ch)) {
        printf("Entered character is lower case alphabet\n");
    } else {
        printf("Entered character is not lower case alphabet\n");
    }

    return 0;
}

