/*
Name : Mathesh
Date : 07.10.2023
Description : Generate positive Fibonacci numbers
Sample input : Enter a number: 8
Sample output : 0 1 1 2 3 5 8
*/

#include <stdio.h>

int main() {
    int n;

    // Input
    printf("Enter a number: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Invalid input\n");
    } else {
        int a = 0, b = 1, c = 0;

        // Print the first two Fibonacci numbers
        printf("0");
        if (n >= 1) {
            printf(" 1");
        }

        // Generate and print the Fibonacci sequence up to 'N'
        while (c <= n) {
            c = a + b;
            if (c <= n) {
                printf(" %d", c);
            }
            a = b;
            b = c;
        }
        printf("\n");
    }

    return 0;
}

