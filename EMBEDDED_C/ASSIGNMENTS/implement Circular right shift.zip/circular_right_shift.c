/*
Name : Mathesh
Date : 28.11.2023
Description : Implement Circular right shift
Sample input : Enter num: 12
			   Enter n : 3
Sample output : Result : 10000000 00000000 00000000 00000001
*/


#include <stdio.h>

// Function to display binary representation of a number
void displayBinary(unsigned int num);

// Function to perform circular right shift on 'num' by 'n' positions
unsigned int circularRightShift(unsigned int num, int n);

int main() {
    int num, n;

    // Input
    //printf("Enter num: ");
    scanf("%d", &num);

   // printf("Enter n : ");
    scanf("%d", &n);

    // Perform circular right shift
    unsigned int result = circularRightShift(num, n);

    // Output binary representation
    printf("Result in Binary: ");
    displayBinary(result);

    return 0;
}

void displayBinary(unsigned int num) {
    int size = sizeof(num) * 8; // Assuming 8 bits per byte
    for (int i = size - 1; i >= 0; i--) {
        printf("%d ", (num >> i) & 1);
        if (i % 8 == 0)
            printf(" "); // Add space every 8 bits for better readability
    }
    printf("\n");
}


unsigned int circularRightShift(unsigned int num, int n) {
    int size = sizeof(num) * 8; // Size of the integer in bits
    // Create a mask with 'n' ones at the least significant end
    unsigned int mask = (1 << n) - 1;

    // Perform circular right shift
    return (num >> n) | ((num & mask) << (size - n));
}

