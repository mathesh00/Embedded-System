/*
Name : Mathesh
Date : 07.10.2023
Description : Print triangle pattern
Sample input : Enter the number: 4
Sample output : 1 2 3 4
				5    6
				7 8
				9
*/

#include <stdio.h>  
  
int main()  
{  
    int n,count=1;  //input
    printf("Enter the number: ");  
    scanf("%d",&n);  
    for(int i=n;i>=1;i--)  //rows
    {  
      for(int j=1;j<=i;j++)  //colums
      {  
         if(j==1 || j==i || i==n)
		 {	 
          printf("%d ",count++);  //print numbers
		 }
		 else  
		 { 
			 printf("  "); //print spaces inside tringle
		 }	 
      }  
      printf("\n");  
    }  
    return 0;  
}  
