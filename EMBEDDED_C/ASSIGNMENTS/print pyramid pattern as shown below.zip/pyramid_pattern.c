/*
Name : Mathesh
Date : 07.10.2023
Description : Print pyramid pattern
Sample input : Enter the number: 4
Sample output : 4
				3 4
				2 3 4
				1 2 3 4
				2 3 4
				3 4
				4
*/

#include <stdio.h>

int main() {
    int n;

    // Input
    printf("Enter the number: ");
    scanf("%d", &n);

    // Print the pyramid pattern
    for (int i = n; i >= 1; i--) {
        // Print decreasing numbers from i to n
        for (int j = i; j <= n; j++) {
            printf("%d", j);
            if (j < n) {
                printf(" ");
            }
        }
        printf("\n");
    }

    // Print the lower part of the pyramid
    for (int i = 2; i <= n; i++) {
        // Print decreasing numbers from i to n
        for (int j = i; j <= n; j++) {
            printf("%d", j);
            if (j < n) {
                printf(" ");
            }
        }
        printf("\n");
    }

    return 0;
}

