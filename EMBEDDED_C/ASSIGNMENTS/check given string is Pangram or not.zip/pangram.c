/*
Name : Mathesh
Date : 23.10.2023
Description : Check given string is Pangram or not
Sample input : Enter the string: The quick brown fox jumps over the lazy dog
Sample output : The Entered String is a Pangram String
*/


#include <stdio.h>
#include <stdbool.h>
#include <string.h>

bool is_pangram(const char *str);

int main() {
    char input[1000];

    printf("Enter the string: ");
    fgets(input, sizeof(input), stdin);

    if (is_pangram(input)) {
        printf("The Entered String is a Pangram String\n");
    } else {
        printf("The Entered String is not a Pangram String\n");
    }

    return 0;
}

bool is_pangram(const char *str) {
    bool alphabet[26] = {false}; // Initialize an array to track letter occurrence

    for (const char *ptr = str; *ptr; ptr++) {
        if (isalpha(*ptr)) {
            char c = tolower(*ptr); // Convert to lowercase for case insensitivity
            alphabet[c - 'a'] = true; // Mark the corresponding letter as found
        }
    }

    for (int i = 0; i < 26; i++) {
        if (!alphabet[i]) {
            return false; // If any letter is missing, it's not a pangram
        }
    }

    return true; // All letters are present
}

