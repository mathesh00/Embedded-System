/*
Name : Mathesh
Date : 28.11.2023
Description : Implement Circular left shift
Sample input : Enter num: 12
			   Enter n : 3
Sample output : Result in Binary: 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0
*/


#include <stdio.h>

// Function to perform circular left shift on num for n times
int circular_left_shift(int num, int n) {
    unsigned int uNum = num; // Convert to unsigned to handle negative numbers

    // Perform circular left shift n times
    for (int i = 0; i < n; ++i) {
        // Get the leftmost bit
        int leftmost = (uNum & (1 << 31)) >> 31;

        // Left shift and set the rightmost bit with the leftmost bit value
        uNum = (uNum << 1) | leftmost;
    }

    return uNum; // Return the result
}

int main() {
    int num, n;

    // Read input values
    printf("Enter num: ");
    scanf("%d", &num);

    printf("Enter n : ");
    scanf("%d", &n);

    // Call the function and print the result in binary
    int result = circular_left_shift(num, n);
    printf("Result in Binary: ");

    // Print the binary representation
    for (int i = 31; i >= 0; --i) {
        printf("%d ", (result >> i) & 1);
    }

    printf("\n");

    return 0;
}

