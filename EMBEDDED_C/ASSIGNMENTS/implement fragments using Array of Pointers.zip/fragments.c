/*
Name : Mathesh
Date : 08.11.2023
Description : Implement fragments using Array of Pointers
Sample input : Enter no.of rows : 3
			   Enter no of columns in row[0] : 4
			   Enter no of columns in row[1] : 3
			   Enter no of columns in row[2] : 5
			   Enter 4 values for row[0] : 1 2 3 4
			   Enter 3 values for row[1] : 2 5 9
			   Enter 5 values for row[2] : 1 3 2 4 1
Sample output : Before sorting output is:
				1.000000 2.000000 3.000000 4.000000 2.500000
				2.000000 5.000000 9.000000 5.333333
				1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

				After sorting output is:
				1.000000 3.000000 2.000000 4.000000 1.000000 2.200000
				1.000000 2.000000 3.000000 4.000000 2.500000
				2.000000 5.000000 9.000000 5.333333
*/


#include <stdio.h>
#include <stdlib.h>

// Function to implement fragments
void fragments(int rows, int *array)
{
    int i, j;
    float *arr[rows], avg, sum;
    char *temp[rows];

    // Memory allocation and input for each row
    for (i = 0; i < rows; i++)
    {
        // Allocate memory for each row's array of floats, including an extra element for average
        arr[i] = malloc(sizeof(float) * (array[i] + 1));
        // Allocate memory for each row's temp array
        temp[i] = malloc(sizeof(char));
        
        printf("Enter %d values for row[%d] : ", array[i], i);
        for (j = 0; j < array[i]; j++)
        {
            // Read values for each row and calculate sum
            scanf("%f", &arr[i][j]);
            sum = sum + arr[i][j];
        }
        
        // Calculate average for the row and store it in the last element
        avg = (array[i] > 0) ? (sum / array[i]) : 0;
        arr[i][j] = avg;

        // Reset sum for the next row
        sum = 0;
    }

    // Display the array before sorting
    printf("Before Sorting output is:\n");
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < array[i] + 1; j++)
        {
            printf("%f ", arr[i][j]);
        }
        printf("\n");
    }

    // Sorting rows based on the average
    for (i = 0; i < rows - 1; i++)
    {
        for (j = 0; j < rows - i - 1; j++)
        {
            if (arr[j][array[j]] > arr[j + 1][array[j + 1]])
            {
                // Swap rows
                float *temp_row = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp_row;

                // Swap array sizes
                int temp_size = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp_size;
            }
        }
    }

    // Display the array after sorting
    printf("After Sorting output is:\n");
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < array[i] + 1; j++)
        {
            printf("%f ", arr[i][j]);
        }
        printf("\n");
    }

    // Free allocated memory
    for (i = 0; i < rows; i++)
    {
        free(arr[i]);
        free(temp[i]);
    }
}

int main()
{
    int rows, i;
    printf("Enter no.of rows : ");
    scanf("%d", &rows);

    int array[rows];
    for (i = 0; i < rows; i++)
    {
        printf("Enter no of columns in row[%d] : ", i);
        scanf("%d", &array[i]);
    }

    // Call the fragments function with the user inputs
    fragments(rows, array);

    return 0;
}

