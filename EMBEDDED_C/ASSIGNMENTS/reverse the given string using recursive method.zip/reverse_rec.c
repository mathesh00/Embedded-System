/*
Name : Mathesh
Date : 02.11.2023
Description : Reverse the given string using recursive method
Sample input : Enter a string : EMERTXE
Sample output : Reverse string is : EXTREME
*/


#include <stdio.h>
#include <string.h>

void reverse_recursive(char str[], int start, int end);

int main() {
    char str[30];

    printf("Enter a string : ");
    scanf("%[^\n]", str);

    // Call the reverse_recursive function with appropriate arguments
    reverse_recursive(str, 0, strlen(str) - 1);

    printf("Reversed string is %s\n", str);

    return 0;
}

// Recursive function to reverse a string
void reverse_recursive(char str[], int start, int end) {
    // Base case: if start index is greater than or equal to end index, stop recursion
    if (start >= end) {
        return;
    }

    // Swap characters at start and end indices
    char temp = str[start];
    str[start] = str[end];
    str[end] = temp;

    // Recursively call the function with updated start and end indices
    reverse_recursive(str, start + 1, end - 1);
}

