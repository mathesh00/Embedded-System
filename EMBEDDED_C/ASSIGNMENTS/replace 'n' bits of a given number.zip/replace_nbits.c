/*
Name : Mathesh
Date : 14.10.2023
Description : Replace 'n' bits of a given number
Sample input : Enter the number: 10
			   Enter number of bits: 3
			   Enter the value: 12
Sample output : Result = 12
*/

#include <stdio.h>

int replace_nbits(int, int, int);

int main() {
    int num, n, val, res = 0;

    printf("Enter the number: ");
    scanf("%d", &num);

    printf("Enter number of bits: ");
    scanf("%d", &n);

    printf("Enter the value: ");
    scanf("%d", &val);

    res = replace_nbits(num, n, val);

    printf("Result = %d\n", res);

    return 0;
}

int replace_nbits(int num, int n, int val) {
    // Create a bitmask for 'n' bits
    int bitmask = (1 << n) - 1;

    // Extract 'n' bits from the LSB of 'val'
    int bits_from_val = val & bitmask;

    // Clear the 'n' bits from 'num' at the same position
    num &= ~(bitmask << 0);

    // Set the 'n' bits in 'num' with the extracted bits from 'val'
    num |= bits_from_val << 0;

    return num;
}

