/*
Name : Mathesh
Date : 04.11.2023
Description : Variance calculation with dynamic arrays
Sample input : Enter the no.of elements : 10
			   Enter the 10 elements:
			   [0] -> 9
			   [1] -> 12
			   [2] -> 15
			   [3] -> 18
			   [4] -> 20
			   [5] -> 22
			   [6] -> 23
			   [7] -> 24
			   [8] -> 26
			   [9] -> 31
Sample output : Variance is 40.000000
*/


#include <stdio.h>
#include <stdlib.h>  

// Function to calculate the mean of an array
float calculateMean(int arr[], int size) {
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return (float)sum / size;
}

// Function to calculate the variance of an array
float calculateVariance(int arr[], int size) {
    float mean = calculateMean(arr, size);
    float sumOfSquaredDifferences = 0;

    // Calculate the sum of squared differences from the mean
    for (int i = 0; i < size; i++) {
        float difference = arr[i] - mean;
        sumOfSquaredDifferences += difference * difference;
    }

    // Calculate the variance
    return sumOfSquaredDifferences / size;
}

int main() {
    int n;

    // Input: Read the number of elements from the user
    printf("Enter the no.of elements : ");
    scanf("%d", &n);

    // Dynamic Memory Allocation: Allocate memory for the array
    int *arr = (int *)malloc(n * sizeof(int));

    // Input: Read the elements of the array
    printf("Enter the %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        printf("[%d] -> ", i);
        scanf("%d", &arr[i]);
    }

    // Calculate and output the variance
    float variance = calculateVariance(arr, n);
    printf("Variance is %.6f\n", variance);

    // Dynamic Memory Deallocation: Free the allocated memory
    free(arr);

    return 0;
}

