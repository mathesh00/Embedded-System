
/*
Name : Mathesh
Date : 16.10.2023
Description : Implement your own isxdigit() function 
Sample input : Enter the character: a
Sample output : Entered character is an hexadecimal digit
*/


#include <stdio.h>

int isxdigit(int c) {
    return ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f'));
}

int main() {
    char ch;

    printf("Enter the character: ");
    scanf(" %c", &ch);  // Note the space before %c to consume whitespace

    if (isxdigit(ch)) {
        printf("Entered character is an hexadecimal digit.\n");
    } else {
        printf("Entered character is not an hexadecimal digit.\n");
    }

    return 0;
}

