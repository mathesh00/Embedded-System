/*
Name : Mathesh
Date : 17.11.2023
Description : Count no. of characters, words and lines, entered through stdin
Sample input : Hello world
               Dennis Ritchie
               Linux
Sample output : Character count : 33
                Line count : 3
                Word count : 5
*/

#include <stdio.h>

int main() {
    char ch;
    int line_count = 0, word_count = 0, char_count = 0;
    int inWord = 0;  /* 0 means not in a word, 1 means in a word */

    while ((ch = getchar()) != EOF) {
        if (ch == '\n') {
            line_count++;
            inWord = 0;
        } else if (ch == ' ' || ch == '\t') {
            if (inWord) {
                inWord = 0;
                word_count++;
            }
        } else {
            if (!inWord) {
                inWord = 1;
                word_count++;
            }
        }
        char_count++;
    }

    /*If the last character was part of a word, increment word_count*/
    if (inWord) {
        word_count++;
    }

    printf("Character count : %d\n", char_count);
    printf("Line count : %d\n", line_count);
    printf("Word count : %d\n", word_count);

    return 0;
}
