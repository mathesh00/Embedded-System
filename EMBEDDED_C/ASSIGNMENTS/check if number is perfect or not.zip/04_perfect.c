/*
Name : Mathesh
Date : 07.10.2023
Description : Check if number is perfect or not
Sample input : Enter a number: 6
Sample output : Yes, entered number is perfect number
*/

#include <stdio.h>

int main() {
    int n, sum = 0;

    // Input
    printf("Enter a number: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Error : Invalid Input, Enter only positive number\n");
    } else {
        // Find the sum of proper divisors
        for (int i = 1; i <= n / 2; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }

        // Check if it's a perfect number
        if (sum == n) {
            printf("Yes, entered number is perfect number\n");
        } else {
            printf("No, entered number is not a perfect number\n");
        }
    }

    return 0;
}

