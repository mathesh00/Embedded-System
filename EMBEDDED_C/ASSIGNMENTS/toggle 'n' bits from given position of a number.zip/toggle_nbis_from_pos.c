/*
Name : Mathesh
Date : 15.10.2023
Description : Toggle 'n' bits from given position of a number
Sample input : Enter the number: 10
	       Enter number of bits: 3
	       Enter the pos: 5
Sample output : Result = 50
*/


#include <stdio.h>

int main(void) {
    int num, n, pos;

    printf("Enter the number: ");
    scanf("%d", &num);

    printf("Enter number of bits: ");
    scanf("%d", &n);

    printf("Enter the pos: ");
    scanf("%d", &pos);

    int ans = num; // Initialize ans with the original number

    for (int bit = 0; bit < n; bit++) {
        int value = (num >> (pos - bit)) & 1;
        ans ^= (1 << (pos - bit)); // Toggle the bit
    }

    printf("Result = %d\n", ans);

    return 0;
}

