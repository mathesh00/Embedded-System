/*
Name : Mathesh
Date : 08.10.2023
Description : Check N th bit is set or not, If yes, clear the M th bit
Sample input : Enter the number: 19
			   Enter 'N': 1
			   Enter 'M': 4
Sample output : Updated value of num is 3
				
*/


#include <stdio.h>

int main()
{
    // Declare three integer variables x, n, and m
    int x, n, m;

    // Input the value of x, n, and m from the user
    printf("Enter the number: ");
    scanf("%d", &x);
    printf("Enter 'N': ");
    scanf("%d", &n);
    printf("Enter 'M': ");
    scanf("%d", &m);

    // Check if the Nth bit of x is equal to 1 (is set)
    if ((x >> n) & 0x01 == 1)
    {
        // Then, clear Mth bit of x
        x &= ~(1 << m);
    }

    // Print the value of x
    printf("Updated value of num is %d\n", x);
    return 0;
}
