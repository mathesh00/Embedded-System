/*
Name : Mathesh
Date : 20.10.2023
Description : Find factorial of given number using recursion
Sample input : Enter the value of N : 7
Sample output : Factorial of the given number is 5040
*/


#include <stdio.h>

unsigned long long int factorial(int num) {
    if (num < 0) {
        return 0;  // Factorial is not defined for negative numbers
    } else if (num == 0 || num == 1) {
        return 1;  // Factorial of 0 and 1 is 1
    } else {
        return num * factorial(num - 1);
    }
}

int main() {
    int num;

    printf("Enter the value of N : ");
    scanf("%d", &num);

    if (num < 0) {
        printf("Invalid Input\n");
    } else {
        unsigned long long int result = factorial(num);
        printf("Factorial of the given number is %llu\n", result);
    }

    return 0;
}

