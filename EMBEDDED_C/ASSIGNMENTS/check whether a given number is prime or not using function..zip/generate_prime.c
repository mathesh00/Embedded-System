/*
Name : Mathesh
Date : 22.10.2023
Description : Check whether a given number is prime or not using function
Sample input : Enter a number: 2
Sample output : 2 is a prime number
*/


#include <stdio.h>

int is_prime(int num);

int main() {
    int number;

    //printf("Enter a number: ");
    scanf("%d", &number);

    if (number < 2) {
        printf("Invalid input\n");
    } else {
        if (is_prime(number)) {
            printf("%d is a prime number\n", number);
        } else {
            printf("%d is not a prime number\n", number);
        }
    }

    return 0;
}

int is_prime(int num) {
    if (num < 2) {
        return 0; // Numbers less than 2 are not prime
    }

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return 0; // It's not prime
        }
    }
    return 1; // It's prime
}

