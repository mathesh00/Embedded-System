/*
Name : Mathesh
Date : 15.10.2023
Description : get 'n' bits from given position of a number
Sample input : Enter the number: 12
			   Enter number of bits: 3
			   Enter the pos: 4
Sample output : Result = 3
*/

#include <stdio.h>

int get_nbits_from_pos(int num, int n, int pos) {
    int mask = (1 << n) - 1;  // Create a mask with 'n' bits set to 1
    mask <<= (pos - n + 1);   // Shift the mask to the specified position

    int result = (num & mask) >> (pos - n + 1);  // Extract the bits and shift them to the rightmost position

    return result;
}

int main() {
    int num, n, pos, res;
    
    printf("Enter the number: ");
    scanf("%d", &num);

    printf("Enter number of bits: ");
    scanf("%d", &n);

    printf("Enter the pos: ");
    scanf("%d", &pos);

    res = get_nbits_from_pos(num, n, pos);

    printf("Result = %d\n", res);

    return 0;
}

