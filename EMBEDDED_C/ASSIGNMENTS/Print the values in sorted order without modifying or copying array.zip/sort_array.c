/*
Name : Mathesh
Date : 22.10.2023
Description : Print the values in sorted order without modifying or copying array
Sample input : Enter the size : 5
			   Enter 5 elements 
			   10 1 3  8 -1
Sample output : After sorting: -1 1 3 8 10
				Original array values 10 1 3 8 -1
*/


#include <stdio.h>

void print_sort(int arr[], int size);

int main() {
    int size, iter;

    printf("Enter the size : ");
    scanf("%d", &size);

    if (size <= 0) {
        printf("Invalid size. Please enter a positive number.\n");
        return 1;
    }

    int arr[size];

    printf("Enter %d elements\n", size);
    for (iter = 0; iter < size; iter++) {
        scanf("%d", &arr[iter]);
    }

    print_sort(arr, size);

    printf("Original array values ");
    for (iter = 0; iter < size; iter++) {
        printf(" %d", arr[iter]);
    }

    return 0;
}

void print_sort(int arr[], int size) {
    int sorted[size];
    int processed[size]; // A flag to keep track of processed elements

    for (int i = 0; i < size; i++) {
        processed[i] = 0; // Initialize all elements as unprocessed
    }

    for (int i = 0; i < size; i++) {
        int min_val = __INT_MAX__;
        int min_index = -1;

        for (int j = 0; j < size; j++) {
            if (!processed[j] && arr[j] < min_val) {
                min_val = arr[j];
                min_index = j;
            }
        }

        sorted[i] = min_val;
        processed[min_index] = 1; // Mark the element as processed
    }

    printf("After sorting: ");
    for (int i = 0; i < size; i++) {
        printf(" %d", sorted[i]);
    }
    printf("\n");
}

