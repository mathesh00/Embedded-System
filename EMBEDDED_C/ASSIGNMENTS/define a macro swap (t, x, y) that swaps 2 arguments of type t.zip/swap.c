/*
Name : Mathesh
Date : 10.11.2023
Description : Define a macro swap (t, x, y) that swaps 2 arguments of type t
Sample input : Enter the num1 : 10
		       Enter the num2 : 20
Sample output : After Swapping :
				num1 : 20
				num2 : 10
*/


#include <stdio.h>

// Macro to swap two variables of type t
#define swap(t, x, y) do { t temp = x; x = y; y = temp; } while (0)

int main() {
    int choice;

    printf("1. Int\n2. char\n3. short\n4. float\n5. double\n6. string\n");
    printf("Enter your choice : ");
    scanf("%d", &choice);

    switch (choice) {
        case 1: {
            int num1, num2;
            printf("\nEnter the num1 : ");
            scanf("%d", &num1);
            printf("Enter the num2 : ");
            scanf("%d", &num2);

            // Swap two integers
            swap(int, num1, num2);

            printf("After Swapping :\nnum1 : %d\nnum2 : %d\n", num1, num2);
            break;
        }
        // Add cases for other types as needed

        default:
            printf("Invalid choice\n");
            break;
    }

    return 0;
}

