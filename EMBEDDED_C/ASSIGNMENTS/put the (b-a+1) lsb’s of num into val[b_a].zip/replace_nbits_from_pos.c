/*
Name : Mathesh
Date : 28.10.2023
Description : Put the (b-a+1) lsb’s of num into val[b:a]
Sample input : Enter the value of 'num' : 11
			   Enter the value of 'a' : 3
			   Enter the value of 'b' : 5
			   Enter the value of 'val': 174
Sample output : Result : 158
*/


#include <stdio.h>

// Function to replace n bits from position a to b in val with the corresponding bits from num
int replace_nbits_from_pos(int num, int a, int b, int val) {
    // Create a mask to preserve the bits outside the range [a, b]
    int mask = ((1 << (b - a + 1)) - 1) << a;

    // Clear the bits in val from position a to b
    val &= ~mask;

    // Extract the bits from num and place them in val
    val |= (num << a) & mask;

    return val;
}

int main() {
    int num, a, b, val;

    // Read input values
    printf("Enter the value of 'num' : ");
    scanf("%d", &num);

    printf("Enter the value of 'a' : ");
    scanf("%d", &a);

    printf("Enter the value of 'b' : ");
    scanf("%d", &b);

    printf("Enter the value of 'val': ");
    scanf("%d", &val);

    // Check if b is within limit
    if (b < a || b > 31) {
        printf("Error: b should be between a and 31 (inclusive)\n");
        return 1;
    }

    // Call the function and print the result
    int result = replace_nbits_from_pos(num, a, b, val);
    printf("Result : %d\n", result);

    return 0;
}

  
