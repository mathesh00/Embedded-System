/*
Name : Mathesh
Date : 07.10.2023
Description : Generate negative Fibonacci numbers
Sample input : Enter a number: -8
Sample output : 0 1 -1 2 -3 5 -8
*/

#include <stdio.h>

int main() {
    int num, a = 0, b = 1;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (num <= 0) {
        if (num == 0) {
            printf("0\n");
        } else if (num == -1) {
            printf("0 1 -1\n");
        } else if (num == -2) {
            printf("0 1 -1 2\n");
        } else {
            printf("0 1 ");
            int next = a - b;
            a = b;
            b = next;
            while (next <= -num) {
                printf("%d", next);
                if (next != -num) {
                    printf(" ");
                }
                next = a - b;
                a = b;
                b = next;
            }
        }
    } else {
        printf("Invalid input\n");
    }

    return 0;
}


