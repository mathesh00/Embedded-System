/*
Name : Mathesh
Date : 08.10.2023
Description : Check whether a given number is prime or not.
Sample input : Enter a number: 2 
Sample output : 2 is a prime number
*/


#include <stdio.h>

int main() {
    int num;

    // Input
    //printf("Enter a number: ");
    scanf("%d", &num);

    if (num < 2) {
        if (num < 0) {
            printf("Invalid input\n");
        } else {
            printf("%d is not a prime number\n", num);
        }
    } else {
        int isPrime = 1;  // Assume the number is prime initially
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                isPrime = 0;  // If it's divisible by i, it's not prime
                break;
            }
        }

        if (isPrime) {
            printf("%d is a prime number\n", num);
        } else {
            printf("%d is not a prime number\n", num);
        }
    }

    return 0;
}

