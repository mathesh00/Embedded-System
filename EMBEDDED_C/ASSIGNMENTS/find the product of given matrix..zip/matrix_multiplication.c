/*
Name : Mathesh
Date : 02.11.2023
Description : Find the product of given matrix.
Sample input : Enter number of rows : 3
			   Enter number of columns : 3
			   Enter values for 3 x 3 matrix :
			   1      2      3
			   1      2      3
			   1      2      3
			   Enter number of rows : 3
			   Enter number of columns : 3
			   Enter values for 3 x 3 matrix :
			   1      1     1
			   2      2     2
			   3      3     3
Sample output : Product of two matrix :
				14      14      14
				14      14      14
				14      14      14
*/


#include <stdio.h>
#include <stdlib.h>

void multiplyMatrices(int **A, int rowsA, int colsA, int **B, int rowsB, int colsB, int **result) {
    if (colsA != rowsB) {
        printf("Matrix multiplication is not possible\n");
        return;
    }

    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsB; j++) {
            result[i][j] = 0;
            for (int k = 0; k < colsA; k++) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void printMatrix(int **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%-6d", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int rowsA, colsA, rowsB, colsB;

    printf("Enter number of rows : ");
    scanf("%d", &rowsA);

    printf("Enter number of columns : ");
    scanf("%d", &colsA);

    int **A = (int **)malloc(rowsA * sizeof(int *));
    for (int i = 0; i < rowsA; i++) {
        A[i] = (int *)malloc(colsA * sizeof(int));
    }

    printf("Enter values for %d x %d matrix :\n", rowsA, colsA);
    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsA; j++) {
            scanf("%d", &A[i][j]);
        }
    }

    printf("Enter number of rows : ");
    scanf("%d", &rowsB);

    printf("Enter number of columns : ");
    scanf("%d", &colsB);

    if (colsA != rowsB) {
        printf("Matrix multiplication is not possible\n");
        return 0;
    }

    int **B = (int **)malloc(rowsB * sizeof(int *));
    for (int i = 0; i < rowsB; i++) {
        B[i] = (int *)malloc(colsB * sizeof(int));
    }

    printf("Enter values for %d x %d matrix :\n", rowsB, colsB);
    for (int i = 0; i < rowsB; i++) {
        for (int j = 0; j < colsB; j++) {
            scanf("%d", &B[i][j]);
        }
    }

    int **result = (int **)malloc(rowsA * sizeof(int *));
    for (int i = 0; i < rowsA; i++) {
        result[i] = (int *)malloc(colsB * sizeof(int));
    }

    multiplyMatrices(A, rowsA, colsA, B, rowsB, colsB, result);

    printf("Product of two matrix :\n");
    printMatrix(result, rowsA, colsB);

    // Free allocated memory
    for (int i = 0; i < rowsA; i++) {
        free(A[i]);
    }
    free(A);

    for (int i = 0; i < rowsB; i++) {
        free(B[i]);
    }
    free(B);

    for (int i = 0; i < rowsA; i++) {
        free(result[i]);
    }
    free(result);

    return 0;
}

