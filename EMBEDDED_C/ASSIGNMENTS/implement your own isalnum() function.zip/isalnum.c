/*
Name : Mathesh
Date : 15.10.2023
Description : Implement your own isalnum() function
Sample input : An ASCII characte
Sample output : 0 or non-zero value based on condition success or failure
*/


#include <stdio.h>

int my_isalpha(int c);
int my_isdigit(int c);
int my_isalnum(int c);

int main() {
    char ch;

    printf("Enter the character: ");
    scanf("%c", &ch);

    if (my_isalnum(ch)) {
        printf("Entered character is alphanumeric character\n", ch);
    } else {
        printf("Entered character is not alphanumeric character\n", ch);
    }

    return 0;
}

int my_isalpha(int c) {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

int my_isdigit(int c) {
    return c >= '0' && c <= '9';
}

int my_isalnum(int c) {
    return my_isalpha(c) || my_isdigit(c);
}

