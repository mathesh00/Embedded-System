/*
Name : Mathesh
Date : 14.10.2023
Description : Print 'n' bits from LSB of a number
Sample input : Enter the number: 10
			   Enter number of bits: 12
Sample output : Binary form of 10: 0 0 0 0 0 0 0 0 1 0 1 0
*/


#include <stdio.h>

// Function to extract and print the least significant 'n' bits of a number
void extractAndPrintBits(int num, int n) {
    int bits[n];  // Array to store the 'n' LSB bits
    int size = n;  // Store 'n' in another variable for later use.
    int number = num;

    // Get the LSB 'n' times
    while (n > 0) {
        int temp = (num & 1);  // Current LSB
        num = num >> 1;  // Right-shift the number
        bits[n - 1] = temp;  // Store the bit in the bits array
        n--;  // Reduce 'n'
    }

    // Print all the bits at the end
    printf("Binary form of %d: ", number);
    for (int i = 0; i < size; i++) {
        printf("%d ", bits[i]);
    }
}

int main() {
    int num, n;  // Declare num and n variables

    printf("Enter the number: ");  // Ask the user to enter the number
    scanf("%d", &num);  // Store the number in the num variable

    printf("Enter number of bits: ");  // Ask the user to enter the number of bits
    scanf("%d", &n);  // Store the number of bits

    extractAndPrintBits(num, n);  // Call the function to extract and print bits

    return 0;
}

