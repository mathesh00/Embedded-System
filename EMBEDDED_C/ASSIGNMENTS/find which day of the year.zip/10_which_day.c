/*
Name : Mathesh
Date : 08.10.2023
Description : To find which day of the year
Sample input : Enter the value of 'n' : 9
			   Choose First Day :
			   1. Sunday
			   2. Monday
			   3. Tuesday
			   4. Wednesday
			   5. Thursday
			   6. Friday
			   7. Saturday
			   Enter the option to set the first day : 2
Sample output : The day is Tuesday
*/

#include <stdio.h>

int main() {
    int n; // Day of the year (1 to 365)
    int startDay; // Starting day of the week (1 to 7)

    // Input for 'n'
    printf("Enter the value of 'n' (1 to 365): ");
    scanf("%d", &n);

    // Check if 'n' is within the valid range
    if (n < 1 || n > 365) {
        printf("Error: Invalid Input, n value should be > 0 and <= 365\n");
        return 1; // Exit with an error code
    }

    // Input for the starting day
    printf("Choose First Day:\n");
    printf("1. Sunday\n2. Monday\n3. Tuesday\n4. Wednesday\n5. Thursday\n6. Friday\n7. Saturday\n");
    printf("Enter the option to set the first day (1 to 7): ");
    scanf("%d", &startDay);

    // Check if 'startDay' is within the valid range
    if (startDay < 1 || startDay > 7) {
        printf("Error: Invalid input, first day should be > 0 and <= 7\n");
        return 1; // Exit with an error code
    }

    // Calculate the day of the week for 'n'
    int dayOfWeek = ((n + startDay - 2) % 7) + 1;

    // Print the result
    switch (dayOfWeek) {
        case 1:
            printf("The day is Sunday\n");
            break;
        case 2:
            printf("The day is Monday\n");
            break;
        case 3:
            printf("The day is Tuesday\n");
            break;
        case 4:
            printf("The day is Wednesday\n");
            break;
        case 5:
            printf("The day is Thursday\n");
            break;
        case 6:
            printf("The day is Friday\n");
            break;
        case 7:
            printf("The day is Saturday\n");
            break;
    }

    return 0;
}


