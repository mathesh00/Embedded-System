/*
Name : Mathesh
Date : 08.10.2023
Description : Count number of set bits in a given number and print parity
Sample input : Enter the number : 7
Sample output : Number of set bits = 3
				Bit parity is Odd
*/

#include <stdio.h>

int main() {
    int num;

    // Input
    printf("Enter the number: ");
    scanf("%d", &num);

    int count = 0;
    int mask = 1;

    for (int i = 0; i <= 31; i++) {
        int res = num & mask;
        if (res > 0) {
            count++;
        }
        mask <<= 1;
    }

    printf("Number of set bits = %d\n", count);

    if (count % 2 == 0) {
        printf("Bit parity is Even\n");
    } else {
        printf("Bit parity is Odd\n");
    }

    return 0;
}

