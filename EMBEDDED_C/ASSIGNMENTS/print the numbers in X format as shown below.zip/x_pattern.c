/*
Name : Mathesh
Date : 07.10.2023
Description : Print the numbers in X format as shown below
Sample input : Enter the number: 4
Sample output : 1  4
				 23
				 23
				1  4
*/


#include <stdio.h>

int main() {
    int n;

    // Input
    printf("Enter the number: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (i == j || j == n - i + 1) {
                printf("%d", j);
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }

    return 0;
}

