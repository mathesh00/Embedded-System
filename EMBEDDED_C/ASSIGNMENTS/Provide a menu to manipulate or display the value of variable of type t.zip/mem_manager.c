/*
Name : Mathesh
Date : 04.11.2023
Description : Print all possible combinations of given string
Sample input : Enter a string: abc
Sample output : All possible combinations of given string :abc
				acb
				bca
				bac
				cab
				cba
*/


#include <stdio.h>
#include <string.h>

// Function to swap two characters
void swap(char *a, char *b) {
    char temp = *a;
    *a = *b;
    *b = temp;
}

// Function to check if characters in the string are distinct
int areDistinct(char str[]) {
    int len = strlen(str);
    for (int i = 0; i < len - 1; i++) {
        for (int j = i + 1; j < len; j++) {
            if (str[i] == str[j]) {
                return 0; // Characters are not distinct
            }
        }
    }
    return 1; // All characters are distinct
}

// Recursive function to generate combinations
void combination(char str[], int start, int end) {
    // Base case: when we reach the end of the string
    if (start == end) {
        // Print the current permutation
        printf("%s\n", str);
        return;
    }

    // Iterate through the characters starting from 'start'
    for (int i = start; i <= end; i++) {
        // Swap the characters at positions 'start' and 'i'
        swap(&str[start], &str[i]);

        // Recur for the remaining characters
        combination(str, start + 1, end);

        // Backtrack: Undo the previous swap to explore other possibilities
        swap(&str[start], &str[i]);
    }
}

int main() {
    char str[100];

    // Input: Read a string from the user
    printf("Enter a string: ");
    scanf("%100[^\n]", str);

    // Check if characters are distinct
    if (!areDistinct(str)) {
        // Output: Print an error message if characters are not distinct
        printf("Error: please enter distinct characters.\n");
        return 1; // Exit with an error code
    }

    // Output: Print all possible combinations of the given string
    printf("All possible combinations of given string :");
    combination(str, 0, strlen(str) - 1);

    return 0;
}

