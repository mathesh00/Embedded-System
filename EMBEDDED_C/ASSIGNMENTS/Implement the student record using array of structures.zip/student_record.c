/*
Name : Mathesh
Date : 10.11.2023
Description : Implement the student record using array of structures
Sample input : Enter no.of students : 2
			   Enter no.of subjects : 2
			   Enter the name of subject 1 : Maths
			   Enter the name of subject 2 : Science
			   
			   ----------Enter the student datails-------------
			   Enter the student Roll no. : 1
			   Enter the student 1 name : Nandhu
			   Enter Maths mark : 99
			   Enter Science mark : 91
			
			   ----------Enter the student datails-------------
			   Enter the student Roll no. : 2
			   Enter the student 2 name : Bindhu
			   Enter Maths mark : 88
			   Enter Science mark : 78
			   
			   ----Display Menu----
			   1. All student details
			   2. Particular student details
			   Enter your choice : 2

			   ----Menu for Particular student----
			   1. Name.
			   2. Roll no.
			   Enter you choice : 1
			   Enter the name of the student : Nandhu
Sample output : Roll No.   Name           Maths         Science       Average       Grade
				1              Nandhu        99               91                95                  A
				Do you want to continue to display(Y/y) : n
*/


#include <stdio.h>
#include <string.h>

#define MAX_SUBJECTS 10
#define MAX_NAME_LENGTH 50

struct Student {
    int rollNo;
    char name[MAX_NAME_LENGTH];
    int marks[MAX_SUBJECTS];
    float average;
    char grade;
};

void calculateAverageAndGrade(struct Student *student, int numSubjects) {
    float sum = 0;
    for (int i = 0; i < numSubjects; ++i) {
        sum += student->marks[i];
    }

    student->average = sum / numSubjects;

    if (student->average >= 90) {
        student->grade = 'A';
    } else if (student->average >= 80) {
        student->grade = 'B';
    } else if (student->average >= 70) {
        student->grade = 'C';
    } else if (student->average >= 60) {
        student->grade = 'D';
    } else {
        student->grade = 'F';
    }
}

int main() {
    int numStudents, numSubjects;
    printf("Enter no.of students : ");
    scanf("%d", &numStudents);
    printf("Enter no.of subjects : ");
    scanf("%d", &numSubjects);

    struct Student students[numStudents];
    char subjectNames[MAX_SUBJECTS][MAX_NAME_LENGTH];

    for (int i = 0; i < numSubjects; ++i) {
        printf("Enter the name of subject %d : ", i + 1);
        scanf("%s", subjectNames[i]);
    }

    for (int i = 0; i < numStudents; ++i) {
        printf("----------Enter the student datails-------------\n");
        printf("Enter the student Roll no. : ");
        scanf("%d", &students[i].rollNo);
        printf("Enter the student %d name : ", i + 1);
        scanf("%s", students[i].name);

        for (int j = 0; j < numSubjects; ++j) {
            printf("Enter %s mark : ", subjectNames[j]);
            scanf("%d", &students[i].marks[j]);
        }

        calculateAverageAndGrade(&students[i], numSubjects);
    }

    int choice;
    do {
        printf("----Display Menu----\n");
        printf("1. All student details\n");
        printf("2. Particular student details\n");
        printf("Enter your choice : ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("\nRoll No.   Name");
                for (int i = 0; i < numSubjects; ++i) {
                    printf("    %s", subjectNames[i]);
                }
                printf("    Average       Grade\n");

                for (int i = 0; i < numStudents; ++i) {
                    printf("%-12d%-15s", students[i].rollNo, students[i].name);
                    for (int j = 0; j < numSubjects; ++j) {
                        printf("%-10d", students[i].marks[j]);
                    }
                    printf("%-15.2f%-6c\n", students[i].average, students[i].grade);
                }
                break;

            case 2: {
                char studentName[MAX_NAME_LENGTH];
                int found = 0;
                printf("\n----Menu for Particular student----\n");
                printf("1. Name.\n");
                printf("2. Roll no.\n");
                printf("Enter you choice : ");
                scanf("%d", &choice);

                switch (choice) {
                    case 1:
                        printf("Enter the name of the student : ");
                        scanf("%s", studentName);

                        for (int i = 0; i < numStudents; ++i) {
                            if (strcmp(students[i].name, studentName) == 0) {
                                if (!found) {
                                    printf("\nRoll No.   Name");
                                    for (int j = 0; j < numSubjects; ++j) {
                                        printf("    %s", subjectNames[j]);
                                    }
                                    printf("    Average       Grade\n");
                                    found = 1;
                                }

                                printf("%-12d%-15s", students[i].rollNo, students[i].name);
                                for (int j = 0; j < numSubjects; ++j) {
                                    printf("%-10d", students[i].marks[j]);
                                }
                                printf("%-15.2f%-6c\n", students[i].average, students[i].grade);
                                break;
                            }
                        }
                        break;

                    default:
                        printf("Invalid choice\n");
                }
                break;
            }

            default:
                printf("Invalid choice\n");
        }

        printf("Do you want to continue to display(Y/y) : ");
        char continueDisplay;
        scanf(" %c", &continueDisplay);
        if (continueDisplay != 'Y' && continueDisplay != 'y') {
            break;
        }

    } while (1);

    return 0;
}

