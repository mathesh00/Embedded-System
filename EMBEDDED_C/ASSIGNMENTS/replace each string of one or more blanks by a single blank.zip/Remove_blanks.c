/*
Name : Mathesh
Date : 23.10.2023
Description : Replace each string of one or more blanks by a single blank
Sample input : Enter the string with more spaces in between two words
		       Pointers     are               sharp     knives.
Sample output : Pointers are sharp knives.
*/


#include <stdio.h>
#include <stdbool.h>

void replace_multiple_spaces(char *);

int main() {
    char input[1000];

   // printf("Enter the string with more spaces in between two words\n");
    scanf("%[^\n]", input);

    replace_multiple_spaces(input);

    printf("%s\n", input);

    return 0;
}

void replace_multiple_spaces(char *str) {
    char *output = str;
    bool inside_word = false;

    while (*str != '\0') {
        if (*str == ' ' || *str == '\t') {
            if (inside_word) {
                *output = ' ';
                output++;
                inside_word = false;
            }
        } else {
            *output = *str;
            output++;
            inside_word = true;
        }
        str++;
    }

    *output = '\0';
}

