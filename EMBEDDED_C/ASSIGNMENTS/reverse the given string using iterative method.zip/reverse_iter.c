/*
Name : Mathesh
Date : 02.11.2023
Description : Reverse the given string using iterative method
Sample input : Enter a string : Hello World
Sample output : Reverse string is : dlroW olleH
*/


#include <stdio.h>
#include <string.h>

void reverse_iterative(char str[]);

int main() {
    char str[30];

    printf("Enter a string : ");
    scanf("%[^\n]", str);

    reverse_iterative(str);

    printf("Reversed string is %s\n", str);

    return 0;
}

void reverse_iterative(char str[]) {
    int length = strlen(str);

    // Use two indices, one from the beginning and one from the end, and swap characters
    for (int start = 0, end = length - 1; start < end; start++, end--) {
        // Swap characters at start and end indices
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
    }
}

