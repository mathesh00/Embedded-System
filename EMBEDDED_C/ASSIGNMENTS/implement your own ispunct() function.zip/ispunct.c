/*
Name : Mathesh
Date : 16.10.2023
Description : Implement your own ispunct() function
Sample input : Enter the character: a
Sample output : Entered character is not punctuation character
*/


#include <stdio.h>
#include <stdbool.h>

int my_ispunct(int c) {
    // Check if the character is a printable character and not a space or an alphanumeric character
    return (c != ' ' && !isalnum(c));
}

int main() {
    char ch;
    int ret;

   // printf("Enter the character: ");
    scanf(" %c", &ch);

    if (my_ispunct(ch)) {
        printf("Entered character is punctuation character\n");
    } else {
        printf("Entered character is not punctuation character\n");
    }

    return 0;
}

