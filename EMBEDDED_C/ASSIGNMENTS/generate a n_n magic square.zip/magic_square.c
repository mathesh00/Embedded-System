/*
Name : Mathesh
Date : 05.11.2023
Description : Generate a n*n magic square
Sample input : Enter a number: 3
Sample output : 8      1      6
				3      5      7
				4      9      2
*/

#include <stdio.h>
#include <stdlib.h>

void generateMagicSquare(int n) {
    if (n % 2 == 0) {
        printf("Error : Please enter only positive odd numbers\n");
        return;
    }

    int **magicSquare = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++) {
        magicSquare[i] = (int *)malloc(n * sizeof(int));
    }

    int num = 1;
    int i = 0, j = n / 2;

    while (num <= n * n) {
        magicSquare[i][j] = num;

        i--;
        j++;

        if (i == -1 && j == n) {
            i = 1;
            j = n - 1;
        } else if (i == -1) {
            i = n - 1;
        } else if (j == n) {
            j = 0;
        }

        if (magicSquare[i][j] != 0) {
            i = i + 2;
            j = j - 1;
        }

        num++;
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%-4d", magicSquare[i][j]);
        }
        printf("\n");
    }

    // Free allocated memory
    for (int i = 0; i < n; i++) {
        free(magicSquare[i]);
    }
    free(magicSquare);
}

int main() {
    int n;

    printf("Enter a number: ");
    scanf("%d", &n);

    generateMagicSquare(n);

    return 0;
}
 
