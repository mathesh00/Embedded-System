/*
Name : Mathesh
Date : 02.11.2023
Description : Implement itoa function
Sample input : Enter the number : 1234
Sample output : Integer to string is 1234
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void itoa(int n, char *s);

int main() {
    char input[20];
    int num;

    printf("Enter the number : ");
    scanf("%s", input);

    num = atoi(input);

    char str[20];
    itoa(num, str);

    printf("Integer to string is %s\n", str);

    return 0;
}

void reverse(char *s);

void itoa(int n, char *s) {
    int i, sign;

    if ((sign = n) < 0)  // Record sign
        n = -n;          // Make n positive

    i = 0;
    do {  // Generate digits in reverse order
        int digit = n % 10;
        if (digit < 0 || digit > 9) {
            strcpy(s, "Invalid input");
            return;
        }
        s[i++] = digit + '0';  // Get next digit
    } while ((n /= 10) != 0);  // Delete it

    if (sign < 0)
        s[i++] = '-';

    s[i] = '\0';
    reverse(s);
}

// Function to reverse a string
void reverse(char *s) {
    int i, j;
    char temp;

    for (i = 0, j = strlen(s) - 1; i < j; i++, j--) {
        temp = s[i];
        s[i] = s[j];
        s[j] = temp;
    }
}
 
