/*
Name : Mathesh
Date : 08.10.2023
Description : Find the median of two unsorted arrays
Sample input : Enter the 'n' value for Array A: 5
			   Enter the 'n' value for Array B: 4
			   Enter the elements one by one for Array A: 3 2 8 5 4
			   Enter the elements one by one for Array B: 12 13 7 5
Sample output : Median of array1 : 4
				Median of array2 : 9.5                                  
				Median of both arrays : 6.75
*/

#include <stdio.h>
int main() 
{
	int n1,n2;
	//Taking input for length of array A
    printf("Enter 'n' value for Array A: ");
	scanf("%d",&n1);

	//Taking input for length of array B
	printf("Enter 'n' value for Array B: ");
	scanf("%d",&n2);

	//Taking input for array members
	int arr1[n1];
	int arr2[n2];
	printf("Enter the elements one by one for Array A: ");
	for(int i = 0; i < n1; i++)
	{
		scanf("%d",&arr1[i]);
	}	
	printf("Enter the elements one by one for Array B: ");
	for(int i = 0; i < n2; i++){
		scanf("%d",&arr2[i]);
	}

	//Sorting first array
	int i,j,a;
	for (i = 0; i < n1; ++i) {
		for (j = i + 1; j < n1; ++j){
			if (arr1[i] > arr1[j]){
				a = arr1[i];
				arr1[i] = arr1[j];
				arr1[j] = a;
			}
		}
	}
	float med1,med2;

	//Printing median of first array
	printf("Median of array1 : ");
	if((n1%2)==0){
		med1 = ((float)(arr1[n1/2] + arr1[n1/2-1])/2);
		printf("%.1f\n",((float)(arr1[n1/2] + arr1[n1/2-1])/2));
	}else{
		med1 = (float)arr1[n1/2];
		printf("%d\n",arr1[n1/2]);
	}

	//Sorting second array
	for (i = 0; i < n2; ++i) {
		for (j = i + 1; j < n2; ++j){
			if (arr2[i] > arr2[j]){
				a = arr2[i];
				arr2[i] = arr2[j];
				arr2[j] = a;
			}
		}
	}

	//Printing median of second array
	printf("Median of array2 : ");
	if((n2%2)==0){
		med2 = ((float)(arr2[n2/2] + arr2[n2/2-1])/2);
		printf("%.1f\n",((float)(arr2[n2/2] + arr2[n2/2-1])/2));
	}else{
		med2 = (float)arr2[n2/2];
		printf("%d\n",arr2[n2/2]);
	}

	//Printing median of both array
	printf("Median of both arrays : ");
	printf("%g\n",((float)(med1+med2)/2));
}
