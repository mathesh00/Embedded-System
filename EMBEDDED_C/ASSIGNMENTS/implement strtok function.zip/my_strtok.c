/*
Name : Mathesh
Date : 05.11.2023
Description : Implement strtok function
Sample input : Enter string1 : Bangalore;;::---Chennai:;Kolkata:;Delhi:-:Mumbai
			   Enter string2 : ;./-:
Sample output : Tokens :
				Bangalore
				Chennai
				Kolkata
				Delhi
				Mumbai
*/


#include <stdio.h>
#include <string.h>
#include <stdio_ext.h>

// Function prototype
char *my_strtok(char str[], const char delim[]);

int main() {
    char str[50], delim[50];

    // Read input string from the user
    printf("Enter the string: ");
    scanf("%s", str);

    // Clear the output buffer to avoid issues with newline characters
    __fpurge(stdout);

    // Read delimiter from the user
    printf("Enter the delimiter: ");
    scanf("\n%s", delim);

    // Clear the output buffer again
    __fpurge(stdout);

    // Function call to tokenize the string
    char *token = my_strtok(str, delim);

    // Display the tokens
    printf("Tokens :\n");
    while (token) {
        printf("%s\n", token);
        token = my_strtok(NULL, delim);
    }

    return 0;
}

// Function definition for custom string tokenization
char *my_strtok(char str[], const char delim[]) {
    int j = 0;
    static int i;
    static char *temp;
    int length = i;

    // If str is not NULL, initialize temp with str
    if (str != NULL) {
        temp = str;
    }

    // Iterate through the characters in the string
    while (temp[i] != '\0') {
        j = 0;

        // Check if the current character is a delimiter
        while (delim[j] != '\0') {
            if (delim[j] == temp[i]) {
                // Replace the delimiter with '\0'
                temp[i] = '\0';
                i++;

                // Return the token if the previous character was not '\0' or if the delimiter is an empty string
                if (temp[length] != '\0' || delim[0] == '\0') {
                    return (&temp[length]);
                } else {
                    // Update length and adjust i to compensate for the upcoming increment
                    length = i;
                    i--;
                    break;
                }
            }
            j++;
        }
        i++;
    }

    // If end of string is reached, return NULL
    if (temp[length] == '\0') {
        return NULL;
    } else {
        // Return the address of the next token
        return (&temp[length]);
    }
}
