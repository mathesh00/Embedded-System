/*
Name : Mathesh
Date : 08.10.2023
Description : Print all primes using Sieve of Eratosthenes method
Sample input : Enter the value of 'n' : 20
Sample output : The primes less than or equal to 20 are : 2, 3, 5, 7, 11, 13, 17, 19
*/

#include <stdio.h>
#include <stdbool.h>

int main() {
    int n;
    printf("Enter the value of 'n': ");
    scanf("%d", &n);

    if (n <= 1) {
        printf("Please enter a positive number which is > 1\n");
        return 0;
    }

    // Declare an array to store prime numbers
    int arr[n - 1];

    // Initialize the array with numbers from 2 to num
    for (int i = 2; i <= n; i++) {
        arr[i - 2] = i;
    }

    // Sieve of Eratosthenes algorithm to find prime numbers
    for (int p = 2; p * p <= n; p++) {
        if (arr[p - 2] != 0) {
            for (int i = p * p; i <= n; i += p) {
                arr[i - 2] = 0; // Mark multiples as 0 (not prime)
            }
        }
    }

    // Print non-zero elements (prime numbers) with commas
    printf("The primes less than or equal to %d are: ", n);
    bool first = true; // Used to skip the comma before the first prime number
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] != 0) {
            if (!first) {
                printf(", ");
            }
            printf("%d", arr[i]);
            first = false;
        }
    }
    printf("\n");

    return 0;
}

