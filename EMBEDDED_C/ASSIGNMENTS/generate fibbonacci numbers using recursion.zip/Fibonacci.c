/*
Name : Mathesh
Date : 20.10.2023
Description : Generate fibbonacci numbers using recursion
Sample input : Enter a number: 8
Sample output : 0, 1, 1, 2, 3, 5, 8
*/


/*
Name : Mathesh
Date : 20.10.2023
Description : Generate fibbonacci numbers using recursion
Sample input : Enter a number: 8
Sample output : 0, 1, 1, 2, 3, 5, 8
*/


#include <stdio.h>

void positive_fibonacci(int, int, int, int);                          // function name and parameters

int main()
{
    int limit;                                                        // variable declaration
             
    printf("Enter a number: ");                                     // read num from user
    scanf("%d", &limit);
    
    positive_fibonacci(limit, 0, 1, 0);
    
    return 0;
}


void positive_fibonacci(int limit, int n1, int n2, int next)         // function prototype
{
    if (limit < 0)                                                   // entered value negative value to print the error message                   
    {
        printf("Invalid input\n");
    }
    while( next <= limit)                                            // to generate the positive fibonacci series	    
    {
		printf("%d,",next);
		n1=n2;
		n2=next;
		next=n1+n2;	    
    }
} 
