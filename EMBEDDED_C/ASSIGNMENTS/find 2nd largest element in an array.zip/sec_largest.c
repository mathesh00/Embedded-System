/*
Name : Mathesh
Date : 19.10.2023
Description : Find 2nd largest element in an array 
Sample input : Enter the size of the Array : 5
			   Enter the elements into the array: 5 1 4 2 8
Sample output : Second largest element of the array is 5
*/


#include <stdio.h>

int sec_largest(int *arr, int size) {
    if (size < 2) {
        printf("Array should have at least two elements to find the second largest.\n");
        return -1;
    }

    int first_max = arr[0];
    int second_max = arr[1];

    if (second_max > first_max) {
        first_max = arr[1];
        second_max = arr[0];
    }

    for (int i = 2; i < size; i++) {
        if (arr[i] > first_max) {
            second_max = first_max;
            first_max = arr[i];
        } else if (arr[i] > second_max && arr[i] != first_max) {
            second_max = arr[i];
        }
    }

    return second_max;
}

int main() {
    int size;

    printf("Enter the size of the Array : ");
    scanf("%d", &size);

    if (size <= 0) {
        printf("Array size should be positive.\n");
        return 1;
    }

    int arr[size];

    printf("Enter the elements into the array: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }

    int result = sec_largest(arr, size);

    if (result != -1) {
        printf("Second largest element of the array is %d\n", result);
    }

    return 0;
}

