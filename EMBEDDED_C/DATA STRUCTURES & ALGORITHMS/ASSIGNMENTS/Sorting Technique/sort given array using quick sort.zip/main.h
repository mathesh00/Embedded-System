/*
Name : Mathesh
Date : 14.12.2023
Description : Sort given array using quick sort
*/


#ifndef MAIN_H
#define MAIN_L

#include <stdio.h>

int quick_sort(int *, int, int );
int partition(int *, int , int );

#endif
