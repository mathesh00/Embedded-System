#include "sll.h"

int sort(Slist **head)
{
    if (*head == NULL || (*head)->link == NULL)
    {
        // List is either empty or has only one element, so it's already sorted
        return SUCCESS;
    }

    int swapped;
    Slist *ptr1;
    Slist *lptr = NULL;

    do
    {
        swapped = 0;
        ptr1 = *head;

        while (ptr1->link != lptr)
        {
            if (ptr1->data > ptr1->link->data)
            {
                // Swap data
                data_t temp = ptr1->data;
                ptr1->data = ptr1->link->data;
                ptr1->link->data = temp;

                swapped = 1;
            }

            ptr1 = ptr1->link;
        }
        lptr = ptr1;
    } while (swapped);

    return SUCCESS;
}
