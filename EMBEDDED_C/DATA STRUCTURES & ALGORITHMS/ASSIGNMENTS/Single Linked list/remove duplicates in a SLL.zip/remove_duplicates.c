#include "sll.h"

int remove_duplicates(Slist **head)
{
	if (*head == NULL)
	{
		return FAILURE;
	}

	Slist *current = *head;

	while (current != NULL)
	{
		Slist *innerCurrent = current;

		while (innerCurrent->link != NULL)
		{
			if (current->data == innerCurrent->link->data)
			{
				Slist *temp = innerCurrent->link;
				innerCurrent->link = innerCurrent->link->link;
				free(temp);
			}
			else
			{
				innerCurrent = innerCurrent->link;
			}
		}

		current = current->link;
	}

	return SUCCESS;
}
