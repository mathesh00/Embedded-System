#include "main.h"


/* Function to check the number is minimum or maximum to decide the position */
void max_heap(int *heap, int i, int size)
{
    // Find largest among root, left child and right child
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
  
    if (left < size && heap[left] > heap[largest])
      largest = left;
  
    if (right < size && heap[right] > heap[largest])
      largest = right;
  
    // Swap and continue heapifying if root is not largest
    if (largest != i) 
    {
      swap(&heap[i], &heap[largest]);
      max_heap(heap, largest, size);
    }
}
